
const expressionDisplay = document.getElementById("expression");
const resultDisplay = document.getElementById("result");
const statusDisplay = document.getElementById("status");
const angleButton = document.getElementById("angleMode");
const historyPanel = document.getElementById("historyPanel");
const historyList = document.getElementById("historyList");

let expression = "";
let degrees = true;
let justCalculated = false;
let history = [];

function insertValue(value) {
    if (justCalculated) {
        if (/^[0-9.]$/.test(value) || value === "pi" || value === "e") {
            expression = "";
        }
        justCalculated = false;
    }

    expression += value;
    statusDisplay.textContent = "Ready";
    updateDisplay();
}

function updateDisplay() {
    expressionDisplay.textContent = expression || "0";

    if (!expression || expression === "-") {
        resultDisplay.textContent = "0";
        return;
    }

    try {
        resultDisplay.textContent = formatNumber(calculate(expression));
    } catch {
        resultDisplay.textContent = "…";
    }
}

function clearAll() {
    expression = "";
    justCalculated = false;
    expressionDisplay.textContent = "0";
    resultDisplay.textContent = "0";
    statusDisplay.textContent = "Ready";
}

function deleteLast() {
    if (justCalculated) {
        clearAll();
        return;
    }

    expression = expression.slice(0, -1);
    statusDisplay.textContent = "Ready";
    updateDisplay();
}

function toggleSign() {
    if (justCalculated) {
        expression = "-(" + expression + ")";
        justCalculated = false;
    } else if (!expression) {
        expression = "-";
    } else {
        expression = "-(" + expression + ")";
    }

    updateDisplay();
}

function factorial(n) {
    if (!Number.isInteger(n) || n < 0 || n > 170) {
        throw new Error("Factorial requires an integer from 0 to 170");
    }

    let result = 1;

    for (let i = 2; i <= n; i++) {
        result *= i;
    }

    return result;
}

function toRadians(value) {
    return degrees ? value * Math.PI / 180 : value;
}

function applyFunction(name, value) {
    switch (name) {
        case "sin":
            return Math.sin(toRadians(value));

        case "cos":
            return Math.cos(toRadians(value));

        case "tan": {
            const angle = toRadians(value);

            if (Math.abs(Math.cos(angle)) < 1e-12) {
                throw new Error("Tangent is undefined at this angle");
            }

            return Math.tan(angle);
        }

        case "sqrt":
            if (value < 0) {
                throw new Error("Square root of a negative number");
            }
            return Math.sqrt(value);

        case "log":
            if (value <= 0) {
                throw new Error("Log requires a positive number");
            }
            return Math.log10(value);

        case "ln":
            if (value <= 0) {
                throw new Error("Ln requires a positive number");
            }
            return Math.log(value);

        default:
            throw new Error("Unknown function");
    }
}

function tokenize(input) {
    const tokens = [];
    let i = 0;

    while (i < input.length) {
        const rest = input.slice(i);

        if (/^\s+/.test(rest)) {
            i += rest.match(/^\s+/)[0].length;
            continue;
        }

        const number = rest.match(
            /^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i
        );

        if (number) {
            tokens.push({
                type: "number",
                value: Number(number[0])
            });
            i += number[0].length;
            continue;
        }

        const identifier = rest.match(/^[a-z]+/i);

        if (identifier) {
            const name = identifier[0].toLowerCase();

            if (name === "pi") {
                tokens.push({ type: "number", value: Math.PI });
            } else if (name === "e") {
                tokens.push({ type: "number", value: Math.E });
            } else if (
                ["sin", "cos", "tan", "sqrt", "log", "ln"].includes(name)
            ) {
                tokens.push({ type: "function", value: name });
            } else {
                throw new Error("Unknown function or constant");
            }

            i += identifier[0].length;
            continue;
        }

        const char = input[i];

        if ("+-*/^()%!".includes(char)) {
            tokens.push({ type: "operator", value: char });
            i++;
            continue;
        }

        throw new Error("Invalid character");
    }

    // Insert implicit multiplication where appropriate.
    const expanded = [];

    for (let i = 0; i < tokens.length; i++) {
        const token = tokens[i];
        const previous = expanded[expanded.length - 1];

        if (previous) {
            const endsValue =
                previous.type === "number" ||
                previous.value === ")" ||
                previous.value === "!";

            const startsValue =
                token.type === "number" ||
                token.type === "function" ||
                token.value === "(";

            // Do not insert multiplication between a function and its '('.
            const functionOpening =
                previous.type === "function" && token.value === "(";

            if (endsValue && startsValue && !functionOpening) {
                expanded.push({ type: "operator", value: "*" });
            }
        }

        expanded.push(token);
    }

    return expanded;
}

function calculate(input) {
    const tokens = tokenize(input);
    let position = 0;

    function peek(value) {
        return tokens[position]?.value === value;
    }

    function take(value) {
        if (peek(value)) {
            position++;
            return true;
        }
        return false;
    }

    function primary() {
        if (take("+")) return unary();
        if (take("-")) return -unary();

        if (take("(")) {
            const value = addSub();

            if (!take(")")) {
                throw new Error("Missing closing parenthesis");
            }

            return value;
        }

        const token = tokens[position];

        if (!token) {
            throw new Error("Incomplete expression");
        }

        if (token.type === "number") {
            position++;
            return token.value;
        }

        if (token.type === "function") {
            position++;

            if (!take("(")) {
                throw new Error("Use parentheses after functions");
            }

            const value = addSub();

            if (!take(")")) {
                throw new Error("Missing closing parenthesis");
            }

            return applyFunction(token.value, value);
        }

        throw new Error("Expected a number");
    }

    function postfix() {
        let value = primary();

        while (take("!")) {
            value = factorial(value);
        }

        return value;
    }

    function power() {
        const value = postfix();

        if (take("^")) {
            return Math.pow(value, unary());
        }

        return value;
    }

    function unary() {
        if (take("+")) return unary();
        if (take("-")) return -unary();
        return power();
    }

    function multiplyDivide() {
        let value = unary();

        while (true) {
            if (take("*")) {
                value *= unary();
            } else if (take("/")) {
                const divisor = unary();

                if (divisor === 0) {
                    throw new Error("Cannot divide by zero");
                }

                value /= divisor;
            } else if (take("%")) {
                // Percentage: 50% becomes 0.5.
                value /= 100;
            } else {
                break;
            }
        }

        return value;
    }

    function addSub() {
        let value = multiplyDivide();

        while (true) {
            if (take("+")) {
                value += multiplyDivide();
            } else if (take("-")) {
                value -= multiplyDivide();
            } else {
                break;
            }
        }

        return value;
    }

    if (tokens.length === 0) {
        throw new Error("Enter a calculation");
    }

    const value = addSub();

    if (position !== tokens.length) {
        throw new Error("Invalid expression");
    }

    if (!Number.isFinite(value)) {
        throw new Error("Result is out of range");
    }

    return value;
}

function formatNumber(value) {
    if (!Number.isFinite(value)) {
        throw new Error("Invalid result");
    }

    if (Object.is(value, -0)) {
        value = 0;
    }

    return Number(value.toPrecision(12)).toString();
}

function calculateFinal() {
    if (!expression) return;

    try {
        const original = expression;
        const value = calculate(original);
        const formatted = formatNumber(value);

        history.unshift({
            expression: original,
            result: formatted
        });

        history = history.slice(0, 30);

        // Keep only the result in the expression for the next calculation.
        expression = formatted;
        justCalculated = true;

        // FIX: Display only the answer after pressing '='.
        expressionDisplay.textContent = formatted;
        resultDisplay.textContent = formatted;

        statusDisplay.textContent = "Calculated";
        renderHistory();
    } catch (error) {
        resultDisplay.textContent = "Error";
        statusDisplay.textContent = error.message;
    }
}

function renderHistory() {
    historyList.replaceChildren();

    if (history.length === 0) {
        historyList.textContent = "No calculations yet.";
        return;
    }

    history.forEach((item) => {
        const entry = document.createElement("div");
        entry.className = "history-item";
        entry.tabIndex = 0;
        entry.setAttribute("role", "button");
        entry.setAttribute(
            "aria-label",
            `${item.expression} equals ${item.result}`
        );

        const equation = document.createElement("div");
        equation.textContent = `${item.expression} =`;

        const result = document.createElement("strong");
        result.textContent = item.result;

        entry.append(equation, result);

        function selectResult() {
            expression = item.result;
            justCalculated = true;
            expressionDisplay.textContent = item.result;
            resultDisplay.textContent = item.result;
            statusDisplay.textContent = "History result selected";
        }

        entry.addEventListener("click", selectResult);

        entry.addEventListener("keydown", (event) => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                selectResult();
            }
        });

        historyList.appendChild(entry);
    });
}

// Connect value buttons.
document.querySelectorAll("[data-value]").forEach((button) => {
    button.addEventListener("click", () => {
        insertValue(button.dataset.value);
    });
});

// Scientific function buttons.
document.querySelectorAll("[data-fn]").forEach((button) => {
    button.addEventListener("click", () => {
        insertValue(button.dataset.fn + "(");
    });
});

// Action buttons.
document.querySelectorAll("[data-action]").forEach((button) => {
    button.addEventListener("click", () => {
        switch (button.dataset.action) {
            case "clear":
                clearAll();
                break;

            case "delete":
                deleteLast();
                break;

            case "sign":
                toggleSign();
                break;

            case "calculate":
                calculateFinal();
                break;
        }
    });
});

// DEG / RAD toggle.
angleButton.addEventListener("click", () => {
    degrees = !degrees;
    angleButton.textContent = degrees ? "DEG" : "RAD";
    statusDisplay.textContent = degrees ? "Degree mode" : "Radian mode";
    updateDisplay();
});

// Show or hide history.
document.getElementById("historyToggle").addEventListener("click", () => {
    historyPanel.classList.toggle("hidden");
});

// Clear history.
document.getElementById("clearHistory").addEventListener("click", () => {
    history = [];
    renderHistory();
});

// Keyboard support.
document.addEventListener("keydown", (event) => {
    if (event.ctrlKey || event.metaKey || event.altKey) return;

    if (/^[0-9.]$/.test(event.key)) {
        insertValue(event.key);
    } else if ("+-*/^()%!".includes(event.key)) {
        insertValue(event.key);
    } else if (event.key === "Enter" || event.key === "=") {
        event.preventDefault();
        calculateFinal();
    } else if (event.key === "Backspace") {
        deleteLast();
    } else if (event.key === "Escape") {
        clearAll();
    }
});

updateDisplay();
